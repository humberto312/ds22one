# ds-xy-js

An first course on data structures and algorithms in three parts, for fresh students, in javascript with an ecmascript 6+ touch. 
