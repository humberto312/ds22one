/** INSTRUCTIONS
 *
 * create one file by program
 * implement a method, function, non-function solution
 * solve each as requested
 * may use code from previous exercises
 *
 * PROBLEM 1
 * half-problem
 * a array-based queue implementation
 * add empty,full methods to enqueue, dequeue methods
 *
 */
