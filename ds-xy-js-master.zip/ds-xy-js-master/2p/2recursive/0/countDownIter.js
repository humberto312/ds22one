//
// iterative
// vs
// countDownRec.js
//

function countdown(number) {
    for(let i = number; i >= 0; i--) {
     	console.log(i);
    }
}

countdown(10)
