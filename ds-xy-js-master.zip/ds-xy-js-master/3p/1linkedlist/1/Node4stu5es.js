//
// ES5
//
// with next QM
// zeeAlso Node4stu6es


function Node(data) {//constructor
   this.data = data
   this.next = null
}
