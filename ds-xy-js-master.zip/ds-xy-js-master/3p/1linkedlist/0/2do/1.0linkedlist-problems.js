/** the PROBLEM with arrays
 *
 * for instance, create 100,000, then:
 * insert a new element at position 3
 * remove element at position 4
 * think about the number of operations that have to be carried out
 *
 * this section has NOT exercises
 */
