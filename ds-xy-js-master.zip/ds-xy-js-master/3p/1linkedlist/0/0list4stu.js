//
// describe
//

let list = {
  key: 'a',
  next: {
    key: 'b',
    next: {
      key: 'c',
      next: null
    }
  }
}
