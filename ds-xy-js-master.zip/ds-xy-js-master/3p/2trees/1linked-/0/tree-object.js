/*
binary tree
*/

let root={
  d:'+',
  l:null,//eft
  r:null//ight
 }

 let n1={
  d:1,
  l:null,
  r:null
 }

 let n2={
  d:2,
  l:null,
  r:null
 }



 root.l=n1
 root.r=n2
