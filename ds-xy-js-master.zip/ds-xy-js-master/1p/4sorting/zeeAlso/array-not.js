//
// 
//

let nums = [3,-2,-1]

console.log(nums)

console.log(nums.sort())//not sorted
