//
// https://ideone.com/00FoC9
//
