//
// 
//

const map = new Map()
    .set(1, 'a1')
    .set(2, 'b1')

map
